package service;

import domain.BankCard;

public interface BankCardService extends BaseService<BankCard,Long> {
}
