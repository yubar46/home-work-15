package service;

import domain.Passenger;

public interface PassengerService extends BaseService<Passenger,Integer> {
}
