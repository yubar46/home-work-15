package repository;

import domain.BankCard;

public interface BankCardRepository extends BaseRepository<BankCard,Long> {
}
