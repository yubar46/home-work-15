package repository;

import domain.Fly;

public interface FlyRepository extends BaseRepository<Fly,Integer> {
}
