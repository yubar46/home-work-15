package repository;

import domain.AirLine;

public interface AirlineRepository extends BaseRepository<AirLine,Integer> {
}
