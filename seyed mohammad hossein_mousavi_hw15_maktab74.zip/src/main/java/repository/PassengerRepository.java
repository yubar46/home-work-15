package repository;

import domain.Passenger;

public interface PassengerRepository extends BaseRepository<Passenger,Integer> {
}
