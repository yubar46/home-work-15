package presentation.console;

public interface Menu {
    Menu action();

}
